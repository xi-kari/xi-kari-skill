#!/usr/bin/env python3
"""Preserve each cell's basis identity in a reproducible candidate comparison.

The table never decides which option is better. Unknown stays unknown and never
becomes zero, worst, or best; a dimension that cannot be ordered produces no
ranking at all; an assumed value is marked wherever it appears. Anything
directional is stated with the conditions it holds under.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from xikari_paths import require_external_output
    from xikari_page import DOWNLOAD, foundation, icon, page_bar
finally:
    sys.path.pop(0)


TOOL = 'xikari-comparison-1'
MD_MARK = '<!-- xikari-comparison-table -->'
HTML_MARK = '<meta name="generator" content="Xikari comparison table">'
OUTPUTS = {'json': 'comparison-results.json', 'md': 'comparison-table.md', 'html': 'comparison-table.html'}
BASIS = {'observed', 'assumed', 'unknown'}
DIRECTIONS = {'higher_is_better', 'lower_is_better', 'not_orderable'}
MAX_CANDIDATES = 16
MAX_DIMENSIONS = 24
IDENTIFIER = re.compile(r'[A-Za-z][A-Za-z0-9._-]{0,63}\Z')
LABEL = {'observed': '事实', 'assumed': '假设', 'unknown': '未知'}
BOUNDARY = '本表只呈现各选项在各维度上的取值与依据身份，不判断方案价值，也不给出整体最优方案。'


TEXT = {
    'zh': {
        'html_lang': 'zh-CN',
        'basis': LABEL,
        'boundary': BOUNDARY,
        'unknown': '未知', 'yes': '是', 'no': '否',
        'not_orderable_reason': 'not_orderable：此维度没有共同的比较尺度，本工具不生成排序。',
        'holds_when': '仅在本次列出的取值与依据条件下成立',
        'non_numeric': '非数值取值，不能参与数值排序',
        'interpretation': '依据身份分别为事实（作者声明有来源，未经验证）、假设与未知。未知未作0、最差或最好处理；'
                          '不可排序维度不产生排序。排序只在本次列出的取值与依据条件下成立，不代表现实中最优或可实施。',
        'fictional': '这是明确虚构的教学比较，取值不是现实事实。',
        'provided': '这是作者提供的比较；各单元格的来源与假设仍需分别判断。',
        'dimension': '维度',
        'mark': '{value}·{basis}',
        'unit': '（{unit}）',
        'legend_line': '标记：事实=作者声明有来源；假设=作者设定；未知=尚无可信取值。',
        'orders_md': '## 各维度排序与不可排序说明',
        'order_intro': '本次取值下的顺序（不代表现实最优）：',
        'ranked_item': '{rank}. {label}：{value}（{basis}）',
        'ranked_item_placed': '- 第 {rank} 位：{label}：{value}（{basis}）',
        'ranked_item_tied': '- 并列第 {rank} 位：{label}：{value}（{basis}）',
        'not_ranked_item': '- 未参与排序：{label}（{reason}）',
        'assumptions': '明确假设',
        'limits': '解释边界',
        'direction': {'higher_is_better': '数值越高越好', 'lower_is_better': '数值越低越好', 'not_orderable': '无共同尺度，不排序'},
        'unranked_reason': {'unknown': '未知，不参与排序', 'not_orderable': '无共同尺度'},
        'order_aria': '本次取值下的顺序',
        'holds': '本次取值下的顺序，不代表现实最优；只在列出的取值与依据条件下成立。',
        'no_order': '没有可参与排序的取值。',
        'not_ranked': '未参与排序：',
        'join': '；',
        'pair': '{label}：{value}',
        'not_orderable_html': '此维度没有共同的比较尺度，本工具不生成排序，只列出各方案的取值。',
        'legend_heading': '怎样读这张表',
        'observed_dd': '作者声明有来源的事实；工具没有核验这个来源。',
        'assumed_dd': '作者设定的假设或方案取值。',
        'unknown_dd': '尚无可信取值。不按 0、最差或最好处理，也不进入任何排序。',
        'table_heading': '比较表',
        'table_note': '每一格都标出它的依据身份，维度名下方注明它的比较方向。方案前的字母是它在下方各维度刻度上的标记。',
        'table_aria': '方案比较，可横向滚动',
        'orders_heading': '各维度的顺序',
        'orders_note': '只在有共同尺度的维度上排列本次取值，并按取值画在该维度自己的刻度上；不跨维度加权，也不给出整体最优方案。未知取值不上刻度。',
        'limits_aria': '假设与边界',
        'download': '下载完整比较结果',
        'source': '来源：{source}（作者声明，未经核验）',
        'unit_html': '单位：{unit}',
        'failed': '比较表生成失败：',
        'overview': '比较概览',
        'strip_options': '方案',
        'unit_option': '个',
        'strip_dimensions': '维度',
        'dimensions_value': '{n} 个',
        'strip_ordered': '可排序维度',
        'strip_unknown': '未知取值',
        'of': '{a} / {b}',
        'strip_identity': '比较身份',
        'identity_fictional': '教学虚构',
        'identity_fictional_note': '取值不是现实事实',
        'identity_provided': '作者提供',
        'identity_provided_note': '来源与假设需分别判断',
        'kind': '方案比较',
    },
    'en': {
        'html_lang': 'en',
        'basis': {'observed': 'Fact', 'assumed': 'Assumption', 'unknown': 'Unknown'},
        'boundary': 'This table shows only each option\'s value on each dimension and the standing of its basis. '
                    'It does not judge the worth of the options or name an overall best option.',
        'unknown': 'Unknown', 'yes': 'Yes', 'no': 'No',
        'not_orderable_reason': 'not_orderable: this dimension has no common scale of comparison, so the tool does not rank it.',
        'holds_when': 'Holds only under the values and bases listed here',
        'non_numeric': 'non-numeric value; cannot take part in a numeric ranking',
        'interpretation': 'Bases are facts (the author states a source; not verified), assumptions and unknowns. Unknowns are not '
                          'treated as zero, worst or best, and dimensions without a common scale are not ranked. Rankings hold only '
                          'under the values and bases listed here; they do not show what is best or feasible in reality.',
        'fictional': 'This is an explicitly fictional teaching comparison; its values are not real-world facts.',
        'provided': 'This comparison was provided by the author; the sources and assumptions of each cell still need to be judged separately.',
        'dimension': 'Dimension',
        'mark': '{value} ({basis})',
        'unit': ' ({unit})',
        'legend_line': 'Marks: Fact = the author states a source; Assumption = set by the author; Unknown = no credible value yet.',
        'orders_md': '## Rankings by dimension, and dimensions without one',
        'order_intro': 'Order under these values (not the best in reality):',
        'ranked_item': '{rank}. {label}: {value} ({basis})',
        'ranked_item_placed': '- Rank {rank}: {label}: {value} ({basis})',
        'ranked_item_tied': '- Rank {rank} (tied): {label}: {value} ({basis})',
        'not_ranked_item': '- Not ranked: {label} ({reason})',
        'assumptions': 'Explicit assumptions',
        'limits': 'Limits of interpretation',
        'direction': {'higher_is_better': 'Higher is better', 'lower_is_better': 'Lower is better', 'not_orderable': 'No common scale; not ranked'},
        'unranked_reason': {'unknown': 'unknown; not ranked', 'not_orderable': 'no common scale'},
        'order_aria': 'Order under these values',
        'holds': 'Order under these values. It is not the best in reality and holds only under the listed values and bases.',
        'no_order': 'No values can be ranked.',
        'not_ranked': 'Not ranked: ',
        'join': '; ',
        'pair': '{label}: {value}',
        'not_orderable_html': 'This dimension has no common scale of comparison. The tool does not rank it and lists each option\'s value only.',
        'legend_heading': 'How to read this table',
        'observed_dd': 'A fact for which the author states a source; the tool has not verified the source.',
        'assumed_dd': 'An assumption or option value set by the author.',
        'unknown_dd': 'No credible value yet. It is not treated as zero, worst or best, and it enters no ranking.',
        'table_heading': 'Comparison table',
        'table_note': 'Every cell shows the standing of its basis, and the direction of comparison is shown under each dimension. '
                      'The letter before an option is its mark on the scales below.',
        'table_aria': 'Option comparison, scrolls horizontally',
        'orders_heading': 'Order within each dimension',
        'orders_note': 'Values are ordered only on dimensions with a common scale and drawn on that dimension\'s own scale; dimensions are not '
                       'weighted against one another, and no overall best option is named. Unknown values are not placed on a scale.',
        'limits_aria': 'Assumptions and limits',
        'download': 'Download the complete comparison results',
        'source': 'Source: {source} (stated by the author, not verified)',
        'unit_html': 'Unit: {unit}',
        'failed': 'Comparison table could not be generated: ',
        'overview': 'Overview of the comparison',
        'strip_options': 'Options',
        'unit_option': '',
        'strip_dimensions': 'Dimensions',
        'dimensions_value': '{n}',
        'strip_ordered': 'Ranked dimensions',
        'strip_unknown': 'Unknown values',
        'of': '{a} / {b}',
        'strip_identity': 'Standing',
        'identity_fictional': 'Fictional teaching example',
        'identity_fictional_note': 'values are not real-world facts',
        'identity_provided': 'Provided by the author',
        'identity_provided_note': 'judge each source and assumption separately',
        'kind': 'Comparison',
    },
}


# Labels the page sets in the display cut. `website/scripts/build_output_fonts.py` cuts the face to them.
DISPLAY_KEYS = ('kind', 'unit_option', 'dimensions_value', 'of', 'download', 'unknown', 'yes', 'no')


def display_strings(lang: str = 'zh') -> list[str]:
    """Every string this page sets in the display cut, for the font build and its check."""
    return [TEXT[lang][key] for key in DISPLAY_KEYS]


def language(result: dict) -> str:
    return result.get('language', 'zh')


class ComparisonError(ValueError):
    """Invalid comparison data."""


def text_field(item, field, where, required=False, limit=8000):
    value = item.get(field, '')
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise ComparisonError(f'{where}.{field}须为{"非空" if required else ""}文本，不超过{limit}字符。')
    return value


def text_list(item, field, where, required=False):
    value = item.get(field, [])
    if not isinstance(value, list) or any(not isinstance(entry, str) or not entry.strip() for entry in value):
        raise ComparisonError(f'{where}.{field}应是文字列表。')
    if required and not value:
        raise ComparisonError(f'{where}.{field}不能为空。')
    return value


def validate_comparison(model) -> None:
    if not isinstance(model, dict) or model.get('schema_version') != 1:
        raise ComparisonError('比较模型须为schema_version=1的JSON对象。')
    extra = set(model) - {'schema_version', 'title', 'purpose', 'fictional', 'assumptions', 'boundaries',
                          'candidates', 'dimensions', 'cells'}
    if extra:
        raise ComparisonError('比较模型含未知字段，不能静默忽略: ' + ', '.join(sorted(extra)))
    text_field(model, 'title', '比较模型', True)
    text_field(model, 'purpose', '比较模型', True)
    if type(model.get('fictional')) is not bool:
        raise ComparisonError('fictional须明确为true或false。')
    text_list(model, 'assumptions', '比较模型', required=True)
    text_list(model, 'boundaries', '比较模型', required=True)
    candidates = model.get('candidates')
    if not isinstance(candidates, list) or not 1 <= len(candidates) <= MAX_CANDIDATES:
        raise ComparisonError(f'candidates须为1—{MAX_CANDIDATES}项的列表。')
    seen = set()
    for item in candidates:
        if not isinstance(item, dict):
            raise ComparisonError('每个候选须为对象。')
        key = item.get('id')
        if not isinstance(key, str) or not IDENTIFIER.fullmatch(key):
            raise ComparisonError(f'候选ID须为英文字母开头的名称: {key!r}')
        if key in seen:
            raise ComparisonError(f'候选ID重复: {key}')
        seen.add(key)
        text_field(item, 'label', f'候选 {key}', True)
    dimensions = model.get('dimensions')
    if not isinstance(dimensions, list) or not 1 <= len(dimensions) <= MAX_DIMENSIONS:
        raise ComparisonError(f'dimensions须为1—{MAX_DIMENSIONS}项的列表。')
    dim_ids = set()
    for item in dimensions:
        if not isinstance(item, dict):
            raise ComparisonError('每个维度须为对象。')
        key = item.get('id')
        if not isinstance(key, str) or not IDENTIFIER.fullmatch(key):
            raise ComparisonError(f'维度ID须为英文字母开头的名称: {key!r}')
        if key in dim_ids:
            raise ComparisonError(f'维度ID重复: {key}')
        dim_ids.add(key)
        text_field(item, 'label', f'维度 {key}', True)
        text_field(item, 'unit', f'维度 {key}')
        if item.get('direction') not in DIRECTIONS:
            raise ComparisonError(f'维度 {key} 的direction须为higher_is_better、lower_is_better或not_orderable。')
    cells = model.get('cells')
    if not isinstance(cells, dict):
        raise ComparisonError('cells须为「候选ID到维度取值」的对象。')
    for key in cells:
        if key not in seen:
            raise ComparisonError(f'cells含未知候选: {key}')
    for key in seen:
        if key not in cells:
            raise ComparisonError(f'候选 {key} 缺少cells条目。')
        row = cells[key]
        if not isinstance(row, dict):
            raise ComparisonError(f'候选 {key} 的cells须为对象。')
        for dim in row:
            if dim not in dim_ids:
                raise ComparisonError(f'候选 {key} 含未知维度: {dim}')
        for dim in dim_ids:
            if dim not in row:
                raise ComparisonError(f'候选 {key} 缺少维度 {dim}；缺失须显式写作unknown，不能省略。')
            cell = row[dim]
            if not isinstance(cell, dict):
                raise ComparisonError(f'候选 {key} 的 {dim} 单元格须为对象。')
            if 'basis' not in cell:
                raise ComparisonError(f'候选 {key} 的 {dim} 单元格须声明basis；缺失不能默认为事实。')
            if cell['basis'] not in BASIS:
                raise ComparisonError(f'候选 {key} 的 {dim} 单元格basis须为observed、assumed或unknown。')
            if 'value' not in cell:
                raise ComparisonError(f'候选 {key} 的 {dim} 单元格须包含value；unknown也须显式写出。')
            value = cell['value']
            if cell['basis'] == 'unknown' and value is not None:
                raise ComparisonError(f'候选 {key} 的 {dim} 标为unknown时value须为null，不能用数值冒充未知。')
            if cell['basis'] != 'unknown' and value is None:
                raise ComparisonError(f'候选 {key} 的 {dim} 有basis={cell["basis"]}却无value。')
            if cell['basis'] == 'observed' and not str(cell.get('source', '')).strip():
                raise ComparisonError(f'候选 {key} 的 {dim} 标为observed须给出source；工具不验证来源真实性。')
            if 'source' in cell:
                text_field(cell, 'source', f'候选 {key} 的 {dim}')
            if value is not None and not (isinstance(value, str) or type(value) in {int, float, bool}):
                raise ComparisonError(f'候选 {key} 的 {dim} value须为文本、数字、布尔或null。')
            if type(value) is float and not math.isfinite(value):
                raise ComparisonError(f'候选 {key} 的 {dim} value须为有限数。')
            text_field(cell, 'note', f'候选 {key} 的 {dim}', limit=8000) if 'note' in cell else None


def read_comparison(path: Path) -> dict:
    data = Path(path).read_bytes()
    if len(data) > 8 * 1024 * 1024:
        raise ComparisonError('比较模型超过8MiB，请拆分为多个比较。')
    text = data.decode('utf-8-sig')
    def reject_duplicates(pairs):
        seen = {}
        for key, value in pairs:
            if key in seen:
                raise ComparisonError(f'JSON含重复键: {key}')
            seen[key] = value
        return seen
    try:
        return json.loads(text, object_pairs_hook=reject_duplicates)
    except json.JSONDecodeError as exc:
        raise ComparisonError(f'比较模型不是有效JSON: {exc}') from exc


def display(value, basis, lang: str = 'zh'):
    if value is None:
        return TEXT[lang]['unknown']
    if type(value) is bool:
        return TEXT[lang]['yes'] if value else TEXT[lang]['no']
    return str(value)


def build_comparison(model: dict, lang: str = 'zh') -> dict:
    """Pure evaluation: no filesystem access, so results are reproducible."""
    if lang not in TEXT:
        raise ComparisonError(f'unsupported language: {lang}')
    T = TEXT[lang]
    validate_comparison(model)
    dimensions = []
    cells_have_assumed = False
    cells_have_unknown = False
    for dimension in model['dimensions']:
        key = dimension['id']
        entry = {
            'id': key, 'label': dimension['label'], 'unit': dimension.get('unit', ''),
            'direction': dimension['direction'],
        }
        values = []
        for candidate in model['candidates']:
            cell = model['cells'][candidate['id']][key]
            values.append({
                'id': candidate['id'], 'label': candidate['label'],
                'value': cell.get('value'), 'basis': cell['basis'],
                'display': display(cell.get('value'), cell['basis'], lang),
                'note': cell.get('note', ''), 'source': cell.get('source', ''),
            })
            if cell['basis'] == 'assumed':
                cells_have_assumed = True
            if cell['basis'] == 'unknown':
                cells_have_unknown = True
        entry['values'] = values
        if dimension['direction'] == 'not_orderable':
            entry['reason'] = T['not_orderable_reason']
            entry['unranked'] = [
                {'id': item['id'], 'label': item['label'], 'reason': 'not_orderable'}
                for item in values
            ]
        else:
            orderable = [item for item in values
                         if item['value'] is not None and type(item['value']) in {int, float}
                         and not isinstance(item['value'], bool)]
            ranked = sorted(orderable, key=lambda item: item['value'],
                            reverse=dimension['direction'] == 'higher_is_better')
            # Equal values share a rank and the next rank counts every option ahead of it (1, 1, 3):
            # the order of the candidates in the model must not be read as an order between them.
            entry['ranking'], rank = [], 0
            for position, item in enumerate(ranked, 1):
                if position == 1 or item['value'] != ranked[position - 2]['value']:
                    rank = position
                entry['ranking'].append({'id': item['id'], 'label': item['label'], 'value': item['value'], 'basis': item['basis'],
                                         'rank': rank, 'holds_when': T['holds_when']})
            entry['unranked'] = [
                {'id': item['id'], 'label': item['label'],
                 'reason': 'unknown' if item['basis'] == 'unknown' else T['non_numeric']}
                for item in values
                if item not in orderable
            ]
        dimensions.append(entry)
    result = {
        'format': TOOL, 'schema_version': 1,
        'title': model['title'], 'purpose': model['purpose'],
        'fictional': model['fictional'],
        'assumptions': model['assumptions'], 'boundaries': model['boundaries'],
        'candidate_count': len(model['candidates']),
        'dimension_count': len(model['dimensions']),
        'candidates': [{'id': item['id'], 'label': item['label']} for item in model['candidates']],
        'dimensions': dimensions,
        'cells_have_assumed': cells_have_assumed,
        'cells_have_unknown': cells_have_unknown,
        'boundary': T['boundary'],
        'interpretation': T['interpretation'],
    }
    if lang != 'zh':
        result['language'] = lang
    return result


def render_json(result: dict) -> str:
    rows = []
    for candidate in result['candidates']:
        values = {}
        for dimension in result['dimensions']:
            cell = next(item for item in dimension['values'] if item['id'] == candidate['id'])
            values[dimension['id']] = {
                'label': dimension['label'], 'value': cell['value'], 'basis': cell['basis'],
                'display': cell['display'], 'note': cell['note'], 'source': cell['source'],
            }
        rows.append({'candidate': candidate['id'], 'label': candidate['label'], 'values': values})
    return json.dumps({**result, 'rows': rows}, ensure_ascii=False, indent=2, allow_nan=False)


def render_markdown(result: dict) -> str:
    T = TEXT[language(result)]
    lines = [MD_MARK, '', f"# {result['title']}", '', result['purpose'], '']
    lines.append(T['fictional'] if result['fictional'] else T['provided'])
    lines.append('')
    candidates = result['candidates']
    lines.append(f"| {T['dimension']} | " + ' | '.join(candidate['label'] for candidate in candidates) + ' |')
    lines.append('| --- | ' + ' | '.join('---' for _ in candidates) + ' |')
    for dimension in result['dimensions']:
        unit = T['unit'].format(unit=dimension['unit']) if dimension['unit'] else ''
        cells = []
        for candidate in candidates:
            cell = next(item for item in dimension['values'] if item['id'] == candidate['id'])
            mark = T['basis'][cell['basis']]
            if cell['basis'] == 'unknown':
                cells.append(T['unknown'])
            else:
                cells.append(T['mark'].format(value=cell['display'], basis=mark))
        lines.append(f"| {dimension['label']}{unit} | " + ' | '.join(cells) + ' |')
    lines.append('')
    lines.append(T['legend_line'] + ('' if language(result) == 'zh' else ' ') + T['boundary'])
    lines.append('')
    lines.append(T['orders_md'])
    lines.append('')
    for dimension in result['dimensions']:
        lines.append(f"### {dimension['label']}")
        lines.append('')
        if 'ranking' in dimension:
            lines.append(T['order_intro'])
            lines.append('')
            # A numbered list renumbers itself when rendered, so where values tie the rank is written out in words.
            ranks = [item['rank'] for item in dimension['ranking']]
            for item in dimension['ranking']:
                form = ('ranked_item' if len(set(ranks)) == len(ranks)
                        else 'ranked_item_tied' if ranks.count(item['rank']) > 1 else 'ranked_item_placed')
                lines.append(T[form].format(rank=item['rank'], label=item['label'], value=item['value'], basis=T['basis'][item['basis']]))
        else:
            lines.append(dimension['reason'])
        for item in dimension['unranked']:
            lines.append(T['not_ranked_item'].format(label=item['label'], reason=T['unranked_reason'].get(item['reason'], item['reason'])))
        lines.append('')
    lines.append('## ' + T['assumptions'])
    lines.append('')
    for entry in result['assumptions']:
        lines.append(f'- {entry}')
    lines.append('')
    lines.append('## ' + T['limits'])
    lines.append('')
    for entry in result['boundaries']:
        lines.append(f'- {entry}')
    lines.append('')
    lines.append(f"> {result['interpretation']}")
    lines.append('')
    return '\n'.join(lines)


ASSETS = Path(__file__).resolve().parents[1] / 'assets'


def comparison_css(lang: str = 'zh') -> str:
    try:
        return foundation(ASSETS, lang) + '\n' + (ASSETS / 'comparison.css').read_text(encoding='utf-8')
    except OSError as exc:
        raise ComparisonError(f'缺少离线展示资源: {exc}') from exc


def title_html(title: str, lang: str = 'zh') -> str:
    head, mark, tail = title.partition('：')
    if not mark and lang != 'zh':
        head, mark, tail = title.partition(': ')
    if mark and head.strip() and tail.strip():
        return (f'<span class="title-main">{html.escape(head)}<span class="title-colon">：</span></span>'
                f'<span class="title-sub">{html.escape(tail)}</span>')
    return html.escape(title)


def basis_tag(basis: str, lang: str = 'zh') -> str:
    return f'<span class="basis basis-{basis}">{TEXT[lang]["basis"][basis]}</span>'


def direction_tag(direction: str, lang: str = 'zh') -> str:
    extra = ' not-orderable' if direction == 'not_orderable' else ''
    return f'<span class="direction{extra}">{TEXT[lang]["direction"][direction]}</span>'


def option_codes(result: dict) -> dict:
    """A letter for each option, in the order given: the mark that ties a column of the table to a point on a scale."""
    return {item['id']: chr(ord('A') + index) for index, item in enumerate(result['candidates'])}


def scale_svg(dimension: dict, codes: dict, lang: str = 'zh') -> str:
    """Where the ranked options stand on this dimension's own scale, by their values.

    Only values that entered the order are placed: an unknown or a value without a number has
    no position. Options with the same value stand one above another. Positions are fractions
    of the drawing's width, so the scale needs no script and prints as it stands.
    """
    ranked = dimension.get('ranking') or []
    if len(ranked) < 2:
        return ''
    groups: dict = {}
    for item in ranked:
        groups.setdefault(item['value'], []).append(item)
    ordered = sorted(groups.items())
    low, high = ordered[0][0], ordered[-1][0]
    try:
        places = [(50.0 if high == low else 5 + 90 * ((value - low) / (high - low)), value, items) for value, items in ordered]
    except OverflowError:
        return ''
    if not all(math.isfinite(place) for place, _, _ in places):
        return ''  # a spread no drawing can hold; the order below still states it
    lowered, flags = False, []
    for index, (place, _, _) in enumerate(places):
        lowered = index > 0 and place - places[index - 1][0] < 9 and not lowered
        flags.append(lowered)
    stack = max(len(items) for _, _, items in places)
    axis = 24 + 14 * (stack - 1) + (13 if any(flags) and stack == 1 else 0)
    parts = [f'<line class="sc-axis" x1="2%" x2="98%" y1="{axis}" y2="{axis}"/>']
    for (place, value, items), shifted in zip(places, flags):
        x = f'{place:.2f}%'
        for level, item in enumerate(items):
            y = axis - 14 * level
            parts.append(f'<circle class="sc-dot is-{item["basis"]}" cx="{x}" cy="{y}" r="6"/>')
            code = html.escape(codes[item['id']])
            if len(items) > 1:
                parts.append(f'<text class="sc-code" x="{x}" y="{y + 4.5}" dx="11">{code}</text>')
            else:
                parts.append(f'<text class="sc-code" x="{x}" y="{axis - (24 if shifted else 11)}" text-anchor="middle">{code}</text>')
        parts.append(f'<text class="sc-value" x="{x}" y="{axis + (35 if shifted else 21)}" text-anchor="middle">'
                     f'{html.escape(display(value, items[0]["basis"], lang))}</text>')
    height = axis + (42 if any(flags) else 28)
    return f'<svg class="scale" height="{height}" aria-hidden="true" focusable="false">{"".join(parts)}</svg>'


def render_html(result: dict) -> str:
    lang = language(result)
    T = TEXT[lang]
    css = comparison_css(lang)
    codes = option_codes(result)
    style_hash = base64.b64encode(hashlib.sha256(css.encode('utf-8')).digest()).decode('ascii')
    csp = f"default-src 'none'; style-src 'sha256-{style_hash}'; font-src data:; base-uri 'none'; form-action 'none'"
    header = ''.join(f'<th scope="col" role="columnheader"><span class="opt-code">{codes[item["id"]]}</span>{html.escape(item["label"])}</th>' for item in result['candidates'])
    orders = []
    for dimension in result['dimensions']:
        unit = T['unit'].format(unit=dimension['unit']) if dimension['unit'] else ''
        head = f'<div class="order-head"><h3>{html.escape(dimension["label"] + unit)}</h3>{direction_tag(dimension["direction"], lang)}</div>'
        if 'ranking' in dimension:
            if dimension['ranking']:
                ranked = ''.join(f'<li><span class="rank">{item["rank"]}</span><span class="opt-code">{codes[item["id"]]}</span><span class="candidate">{html.escape(item["label"])}</span>'
                                 f'<span class="value">{html.escape(display(item["value"], item["basis"], lang))}</span>{basis_tag(item["basis"], lang)}</li>'
                                 for item in dimension['ranking'])
                body = f'{scale_svg(dimension, codes, lang)}<ol class="ranking" aria-label="{T["order_aria"]}">{ranked}</ol><p class="holds">{T["holds"]}</p>'
            else:
                body = f'<p class="no-order">{T["no_order"]}</p>'
            if dimension['unranked']:
                names = T['join'].join(html.escape(item['label']) + html.escape(T['unit'].format(unit=T['unranked_reason'].get(item['reason'], item['reason'])))
                                       for item in dimension['unranked'])
                body += f'<p class="unranked"><strong>{T["not_ranked"]}</strong>{names}</p>'
        else:
            values = ''.join('<li>' + html.escape(T['pair'].format(label=item['label'], value=item['display'])) + ' ' + basis_tag(item['basis'], lang) + '</li>' for item in dimension['values'])
            body = f'<p class="no-order">{T["not_orderable_html"]}</p><ul class="plain-values">{values}</ul>'
        orders.append(f'<article class="order">{head}{body}</article>')
    download = base64.b64encode(render_json(result).encode('utf-8')).decode('ascii')
    ordered = sum(1 for dimension in result['dimensions'] if 'ranking' in dimension)
    unknown = sum(1 for dimension in result['dimensions'] for item in dimension['values'] if item['basis'] == 'unknown')
    cells = result['candidate_count'] * result['dimension_count']
    identity = (f'<span class="basis basis-assumed">{T["identity_fictional"]}</span><span class="strip-aside">{T["identity_fictional_note"]}</span>'
                if result['fictional'] else
                f'<span class="basis basis-observed">{T["identity_provided"]}</span><span class="strip-aside">{T["identity_provided_note"]}</span>')
    strip = (f'<div class="cell-big"><dt>{T["strip_options"]}</dt><dd><span class="strip-big">{result["candidate_count"]}</span>'
             f'<span class="strip-unit">{T["unit_option"]}</span></dd></div>'
             f'<div><dt>{T["strip_dimensions"]}</dt><dd>{T["dimensions_value"].format(n=result["dimension_count"])}</dd></div>'
             f'<div><dt>{T["strip_ordered"]}</dt><dd>{T["of"].format(a=ordered, b=result["dimension_count"])}</dd></div>'
             f'<div><dt>{T["strip_unknown"]}</dt><dd>{T["of"].format(a=unknown, b=cells)}</dd></div>'
             f'<div><dt>{T["strip_identity"]}</dt><dd>{identity}</dd></div>')
    return f'''<!doctype html>
<html lang="{T['html_lang']}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">{HTML_MARK}<meta http-equiv="Content-Security-Policy" content="{html.escape(csp)}"><meta name="color-scheme" content="light dark"><title>{html.escape(result['title'])}</title>
<style>{css}</style></head>
<body><main class="cmp">
{page_bar(T['kind'], TOOL)}
<header class="cmp-header"><h1>{title_html(result['title'], lang)}</h1><p class="cmp-purpose">{html.escape(result['purpose'])}</p></header>
<section class="plate cmp-plate" aria-label="{T['overview']}"><dl class="strip plate-strip">{strip}</dl>
<dl class="basis-legend" aria-label="{T['legend_heading']}"><div><dt>{basis_tag('observed', lang)}</dt><dd>{T['observed_dd']}</dd></div>
<div><dt>{basis_tag('assumed', lang)}</dt><dd>{T['assumed_dd']}</dd></div>
<div><dt>{basis_tag('unknown', lang)}</dt><dd>{T['unknown_dd']}</dd></div></dl>
<p class="boundary">{html.escape(T['boundary'])}</p></section>
<section class="cmp-section" aria-labelledby="table-heading"><h2 id="table-heading">{T['table_heading']}</h2>
<p class="section-note">{T['table_note']}</p>
<div class="table-scroll" tabindex="0" role="region" aria-label="{T['table_aria']}"><table class="cmp-table" role="table">
<thead role="rowgroup"><tr role="row"><th scope="col" role="columnheader" class="corner">{T['dimension']}</th>{header}</tr></thead>
<tbody role="rowgroup">{''.join(dimension_row(item, result, codes) for item in result['dimensions'])}</tbody>
</table></div></section>
<section class="cmp-section" aria-labelledby="orders-heading"><h2 id="orders-heading">{T['orders_heading']}</h2>
<p class="section-note">{T['orders_note']}</p>
<div class="orders">{''.join(orders)}</div></section>
<section class="cmp-section cmp-limits" aria-label="{T['limits_aria']}"><div class="frame-assumed"><h2>{T['assumptions']}</h2><ul>{''.join(f'<li>{html.escape(t)}</li>' for t in result['assumptions'])}</ul></div>
<div class="frame-refused"><h2>{T['limits']}</h2><ul>{''.join(f'<li>{html.escape(t)}</li>' for t in result['boundaries'])}</ul></div></section>
<footer class="cmp-footer dock"><p>{html.escape(result['interpretation'])}</p>
<a id="download" class="download sign sign-go" download="comparison-results.json" href="data:application/json;charset=utf-8;base64,{download}">{icon(DOWNLOAD)}{T['download']}</a></footer>
</main></body></html>'''


def dimension_row(dimension, result, codes):
    """One dimension of the table. Each cell also carries its option's name, which a narrow screen shows above the cell.

    The table keeps its roles in the markup, so it is still read as a table where a narrow screen lays it out as blocks.
    """
    lang = language(result)
    T = TEXT[lang]
    cells = []
    for candidate in result['candidates']:
        cell = next(item for item in dimension['values'] if item['id'] == candidate['id'])
        text = T['unknown'] if cell['basis'] == 'unknown' else cell['display']
        kind = ' value-text' if not isinstance(cell['value'], (int, float)) or isinstance(cell['value'], bool) else ''
        parts = [f'<span class="cell-option"><span class="opt-code">{codes[candidate["id"]]}</span>{html.escape(candidate["label"])}</span>',
                 f'<span class="value{kind}">{html.escape(text)}</span>', basis_tag(cell['basis'], lang)]
        if cell['note']:
            parts.append(f'<span class="note">{html.escape(cell["note"])}</span>')
        if cell['basis'] == 'observed' and cell['source']:
            parts.append('<span class="source">' + html.escape(T['source'].format(source=cell['source'])) + '</span>')
        unknown = ' class="cell-unknown"' if cell['basis'] == 'unknown' else ''
        cells.append(f'<td role="cell"{unknown}>' + ''.join(parts) + '</td>')
    unit = '<span class="dim-unit">' + html.escape(T['unit_html'].format(unit=dimension['unit'])) + '</span>' if dimension['unit'] else ''
    return (f'<tr role="row"><th scope="row" role="rowheader"><span class="dim-label">{html.escape(dimension["label"])}</span>{unit}{direction_tag(dimension["direction"], lang)}</th>'
            + ''.join(cells) + '</tr>')


def owned_output(path: Path, kind: str) -> bool:
    try:
        if kind == 'json':
            return json.loads(path.read_text(encoding='utf-8')).get('format') == TOOL
        if kind == 'html':
            return HTML_MARK in path.read_text(encoding='utf-8')[:4096]
        return path.read_text(encoding='utf-8').startswith(MD_MARK)
    except (OSError, ValueError, AttributeError):
        return False


def same_path(first: Path, second: Path) -> bool:
    if Path(first).resolve() == Path(second).resolve():
        return True
    try:
        return Path(first).samefile(second)
    except OSError:
        return False


def write_outputs(result: dict, source: Path, output: Path, output_format: str = 'all', force: bool = False) -> dict:
    require_external_output(output, __file__)
    kinds = list(OUTPUTS) if output_format == 'all' else [output_format]
    paths = {kind: Path(output) / OUTPUTS[kind] for kind in kinds}
    for kind, path in paths.items():
        require_external_output(path, __file__)
        if same_path(path, source):
            raise ComparisonError('输出路径与输入文件相同，--force也不能覆盖输入。')
        if path.is_symlink():
            raise ComparisonError(f'输出是符号链接，拒绝替换: {path}')
        if path.exists() and (not force or not owned_output(path, kind)):
            raise ComparisonError(f'输出已存在且未授权覆盖本工具产物: {path}；使用新目录，或仅对已有本工具产物使用--force。')
    rendered = {}
    for kind in kinds:
        if kind == 'json':
            rendered[kind] = render_json(result) + '\n'
        elif kind == 'md':
            rendered[kind] = render_markdown(result)
        else:
            rendered[kind] = render_html(result)
        if len(rendered[kind].encode('utf-8')) > 32 * 1024 * 1024:
            raise ComparisonError('单项输出超过32MiB；减少候选或维度数量。')
    lock = Path(output) / '.comparison.lock'
    require_external_output(lock, __file__)
    if same_path(lock, source):
        raise ComparisonError('输出锁路径与输入相同，拒绝写入。')
    Path(output).mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ComparisonError(f'输出目录正在写入或存在遗留锁: {lock}；未自动覆盖。') from exc
    os.close(descriptor)
    staged, previous, changed = {}, {}, []
    try:
        for kind, path in paths.items():
            if path.exists() and (not force or not owned_output(path, kind)):
                raise ComparisonError(f'输出路径在处理期间出现冲突: {path}')
            previous[kind] = path.read_bytes() if path.exists() else None
            fd, name = tempfile.mkstemp(prefix=f'.comparison-{kind}-', suffix='.tmp', dir=Path(output))
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
                stream.write(rendered[kind])
                stream.flush()
                os.fsync(stream.fileno())
            staged[kind] = Path(name)
        for kind, path in paths.items():
            current = path.read_bytes() if path.exists() else None
            if current != previous[kind]:
                raise ComparisonError(f'输出在处理期间被其他工作改变: {path}')
            os.replace(staged[kind], path)
            changed.append((kind, path))
            staged[kind] = None
    except BaseException:
        for kind, path in reversed(changed):
            saved = previous[kind]
            try:
                if saved is None:
                    path.unlink(missing_ok=True)
                else:
                    descriptor, name = tempfile.mkstemp(
                        prefix=f'.comparison-restore-{kind}-', suffix='.tmp', dir=path.parent)
                    with os.fdopen(descriptor, 'wb') as stream:
                        stream.write(saved)
                        stream.flush()
                        os.fsync(stream.fileno())
                    os.replace(name, path)
            except OSError:
                pass
        raise
    finally:
        for temporary in staged.values():
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        lock.unlink(missing_ok=True)
    return {kind: str(path.resolve()) for kind, path in paths.items()}


def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('model', type=Path, help='比较模型 JSON')
    parser.add_argument('--output', '-o', type=Path, required=True, help='安装目录之外的输出目录')
    parser.add_argument('--format', choices=['json', 'md', 'html', 'all'], default='all')
    parser.add_argument('--force', action='store_true', help='仅覆盖本工具先前生成的同名产物')
    parser.add_argument('--lang', choices=sorted(TEXT), default='zh', help='表头、标记与说明的语言：zh（默认）或 en；不翻译模型内容')
    args = parser.parse_args(argv)
    try:
        model = read_comparison(args.model)
        result = build_comparison(model, args.lang)
        outputs = write_outputs(result, args.model, args.output, args.format, args.force)
        print(json.dumps({
            'outputs': outputs,
            'candidates': result['candidate_count'],
            'dimensions': result['dimension_count'],
            'boundary': result['boundary'],
        }, ensure_ascii=False))
        return 0
    except (OSError, UnicodeError, ComparisonError, ValueError) as error:
        print(TEXT[args.lang]['failed'] + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
